﻿using System;
using System.Net.Http.Headers;
using System.Text;
namespace MyProgram
{
    public class Program
    {
        public static void Main(string[] args)
        {

            const string BeforeMenu = "Abans de començar, es recomana l'ús de pantalla completa(prem qualsevol tecla per continuar)";
            const string Menu = " __  __   __   ___  ____  ___  ___   __  __  __  _  _  ___  " +
                "            \r\n(  \\/  ) (  ) / __)(_  _)(  _)(  ,) (  \\/  )(  )( \\( )(   \\ " +
                "            \r\n )    (  /__\\ \\__ \\  )(   ) _) )  \\  )    (  )(  )  (  ) ) )" +
                "           \r\n(_/\\/\\_)(_)(_)(___/ (__) (___)(_)\\_)(_/\\/\\_)(__)(_)\\_)(___/ "
                + "\nHugo Resina\n\n\n\n\n0.- Jugar\n1.- Salir";
            const string ExitedGame = "Adeu, esperem que torins a jugar!";
            const string WannaReplay = "Has acabat!\n0.- Tornar a jugar\n1.- Sortir";
            const string DificultyMenu = "(!SI L'IMPUT DE SELECCIÓ NO CORRESPON A CAP OPCIÓ, SET DONARA UN ÚNIC TORN)\n1.- Dificultat novell: 10 intents\n2.- Dificultat aficionat: 6 intents\n3.- Dificultat expert: 4 intents\n4.- Dificultat Màster: 3 intents\n5.- Dificultat Personalitzada";
            const string EnterDificulty = "Introdueix el numero d'intents que vols:";
            const string InsertTry = "\nIntrodueix un numero de quatre xifres entre [1-6] per intentar trobar el codi ocult:\nSi el numero no es valid, perdras un torn";
            int menuSelect = 0;
            int dificultySelect = 0;
            int tries = 0;
            int usedTries = 0;
            int userInput = 0;
            int code = 1234;

            bool foundCode = false;

            string[] turnsTaken;

            string userInputStr = "";
            string userTry = "";
            


            Console.WriteLine(BeforeMenu);
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine(Menu);
            menuSelect = int.Parse(Console.ReadLine());

            while (AssignBool(menuSelect))
            {
                Console.Clear();
                Console.WriteLine(DificultyMenu);
                dificultySelect = int.Parse(Console.ReadLine());

                if (dificultySelect != 5)
                {
                    AssignAttempts(dificultySelect, out tries);
                }
                else
                {
                    Console.WriteLine(EnterDificulty);
                    tries = int.Parse(Console.ReadLine());
                }
                turnsTaken = new string[tries];
                Console.WriteLine(turnsTaken[0]);
                usedTries = 0;
                foundCode = false;
                Console.Clear();

                while (!foundCode && usedTries < tries)
                {
                    DisplayUsedTurns(tries, usedTries + 1);
                    DisplayTurns(turnsTaken, code);
                    Console.ResetColor();
                    Console.WriteLine(InsertTry);
                    userInput = int.Parse(Console.ReadLine());
                    NumToSpacedString(userInput, out userInputStr);

                    foundCode = ValidateInput(userInput, code);

                    userTry = userInputStr;
                    
                    
                    if (!UnvalidInput(userTry)) 
                    {
                        turnsTaken[usedTries] = userTry;
                    }
                    Console.Clear();
                    usedTries++;
                }

                DisplayTurns(turnsTaken, code);

                Console.WriteLine();

                Console.WriteLine(WannaReplay);
                
                menuSelect = int.Parse(Console.ReadLine());
                AssignBool(menuSelect);
            }
            Console.Clear();
            Console.WriteLine(ExitedGame);
            Console.ReadKey();
        }

        public static bool UnvalidInput(string inpt)
        {
            return (inpt.Contains('7') || inpt.Contains('8') || inpt.Contains('9') || inpt.Contains('0') || inpt.Replace(" ", "").Length != 4);
        }
        public static bool ValidateInput(int userInput, int code)
        {
            return userInput == code;
        }
        public static bool AssignBool(int num)
        {
            return num == 0 ? true : false;
        }
        
        public static void AssignAttempts(int input, out int tries)
        {
            tries = 1;
            switch (input)
            {
                case 1:
                    tries = 10;
                    break;
                case 2:
                    tries = 6;
                    break;
                case 3:
                    tries = 4;
                    break;
                case 4:
                    tries = 3;
                    break;
                case int i when i > 4 && i < 1:
                    tries = 1;
                    break;
            }
        }
        /*NumToSpacedString tranforma un numero en una string amb espais*/
        public static void NumToSpacedString(int num, out string output)
        {
            output = " ";
            foreach (char i in num.ToString())
            {
                output += i.ToString() + " ";
            }

        }
        /*
        ColorDictionary es un "diccionari" per printar tots els numeros 
        del input del user amb un color concret
        */
        public static void ColorDictionaryUser(string num)
        {
            switch (int.Parse(num))
            {
                case 1:
                    Console.BackgroundColor = ConsoleColor.Magenta;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(num);
                    break;
                case 2:
                    Console.BackgroundColor = ConsoleColor.Blue;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(num);
                    break;
                case 3:
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(num);
                    break;
                case 4:
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(num);
                    break;
                case 5:
                    Console.BackgroundColor = ConsoleColor.Cyan;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(num);
                    break;
                case 6:
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(num);
                    break;

            }
            Console.ResetColor();
            Console.Write(" ");

        }

        /*StyleTurn asigna el color a cada numero del input cridant al "diccionari"*/
        public static void StyleTurn(string turn)
        {
            foreach (char i in turn)
            {
                if (i != ' ')
                    ColorDictionaryUser(i.ToString());
            }
        }
        public static void GetAnswerToInput(string input, string code)
        {
            const string NotThere = "\u00D8";
            const string Yes = "O";
            const string No = "X";

            input = input.Replace(" ", "");

            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == code[i])
                {
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(Yes + " ");
                }
                else if (code.Contains(input[i]))
                {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(NotThere + " ");
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(No + " ");
                }
                Console.ResetColor();
            }
            
        }

        /*DisplayTurns printa tots els torns ja presos per donar informacio al user*/
        public static void DisplayTurns(string[] turns, int code)
        {
            for (int i = 0; i < turns.Length; i++)
            {
                if (turns[i] != null)
                {
                    Console.WriteLine();
                    Console.ResetColor();
                    Console.Write("{ ");
                    StyleTurn(turns[i]);
                    Console.ResetColor();
                    Console.Write("} | {");
                    GetAnswerToInput(turns[i], code.ToString());
                    Console.Write(" }");
                }
            }
        }
        /*DisplayUsedTurns printa quants torns hem pres i quans tenim en total*/
        public static void DisplayUsedTurns(int turns, int used)
        {
            Console.WriteLine($"{used}/{turns} torn");
        }
    }
}


